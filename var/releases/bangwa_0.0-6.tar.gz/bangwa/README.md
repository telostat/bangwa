# bangwa: Sandbox R package for missionts research

Please note that the contents of this package may not be of production
quality. Any production-grade functionality is meant to reside in its
own public R package.

We use [semantic versioning](http://semver.org/) and gitflow
[[1]](http://nvie.com/posts/a-successful-git-branching-model/),
[[2]](https://github.com/nvie/gitflow),
[[3]](http://danielkummer.github.io/git-flow-cheatsheet/) for this
repository.

All contents are proprietary. Contact
[Tolga Sezer](mailto:tolgasbox@gmail.com) or
[Vehbi Sinan Tunalioglu](mailto:vst@vsthost.com) for questions and
inquiries.
